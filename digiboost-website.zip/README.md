# Digiboost Website

Static one-page website for Digiboost.

## Files

- `index.html` - Main page content
- `styles.css` - Responsive design and visual system
- `script.js` - Navigation, reveal animations, counters, and contact form UI
- `assets/digiboost-logo.jpeg` - Website logo

## Publish Options

### Netlify

Drag this folder into Netlify Drop or connect the folder to a Git repository. The included `netlify.toml` publishes the current directory.

### Vercel

Import this folder through Vercel or deploy it as a static project. The included `vercel.json` adds clean URLs and basic security headers.

### cPanel / Shared Hosting

Upload `index.html`, `styles.css`, `script.js`, and the `assets` folder to the `public_html` folder of your hosting account.
